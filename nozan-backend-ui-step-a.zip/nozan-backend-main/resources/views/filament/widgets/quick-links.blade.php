<x-filament-widgets::widget>
    <x-filament::section>
        <div class="space-y-4">
            <div>
                <p class="text-xs font-semibold uppercase tracking-[0.3em] text-amber-600">Quick actions</p>
                <h3 class="mt-2 text-xl font-bold text-gray-950 dark:text-white">What you can test now</h3>
            </div>

            <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <a href="{{ url('/') }}" class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/10 dark:bg-white/5">
                    <p class="text-sm font-semibold text-gray-950 dark:text-white">Public landing page</p>
                    <p class="mt-2 text-sm text-gray-500">بینینی UI ـی نوێی root page.</p>
                </a>
                <a href="{{ url('/admin') }}" class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/10 dark:bg-white/5">
                    <p class="text-sm font-semibold text-gray-950 dark:text-white">Admin dashboard</p>
                    <p class="mt-2 text-sm text-gray-500">Filament panel with updated widgets.</p>
                </a>
                <a href="{{ url('/api/auth/me') }}" class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/10 dark:bg-white/5">
                    <p class="text-sm font-semibold text-gray-950 dark:text-white">Auth endpoint</p>
                    <p class="mt-2 text-sm text-gray-500">تاقیکردنەوەی Sanctum protected route.</p>
                </a>
                <a href="{{ url('/ops-preview') }}" class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/10 dark:bg-white/5">
                    <p class="text-sm font-semibold text-gray-950 dark:text-white">Operations preview</p>
                    <p class="mt-2 text-sm text-gray-500">Mock layout بۆ staff/jobs experience.</p>
                </a>
            </div>
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
