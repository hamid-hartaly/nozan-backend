<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ config('app.name', 'Nozan Service Center') }}</title>
        <style>
            :root {
                color-scheme: light dark;
                --navy: #0b1f3a;
                --gold: #d8a21b;
                --surface: #f8fafc;
                --border: #e2e8f0;
                --text: #0f172a;
                --muted: #475569;
                font-family: Inter, Arial, Helvetica, sans-serif;
            }
            * { box-sizing: border-box; }
            body {
                margin: 0;
                min-height: 100vh;
                background: linear-gradient(180deg, #f8fafc 0%, #eef2ff 100%);
                color: var(--text);
            }
            .wrap {
                max-width: 1200px;
                margin: 0 auto;
                padding: 32px 20px 56px;
            }
            .hero {
                display: grid;
                gap: 24px;
                align-items: center;
                grid-template-columns: 1.4fr .9fr;
            }
            .eyebrow {
                margin: 0 0 12px;
                color: var(--gold);
                text-transform: uppercase;
                font-size: 12px;
                letter-spacing: .3em;
                font-weight: 700;
            }
            h1 {
                margin: 0;
                font-size: clamp(40px, 6vw, 72px);
                line-height: 1.03;
                letter-spacing: -0.04em;
            }
            .lead {
                margin-top: 18px;
                color: var(--muted);
                font-size: 19px;
                line-height: 1.75;
                max-width: 720px;
            }
            .actions {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                margin-top: 28px;
            }
            .button {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-height: 48px;
                padding: 0 18px;
                border-radius: 14px;
                text-decoration: none;
                font-weight: 700;
                transition: transform .15s ease, box-shadow .15s ease, opacity .15s ease;
            }
            .button:hover { transform: translateY(-1px); }
            .button-primary {
                background: var(--navy);
                color: white;
                box-shadow: 0 12px 24px rgba(11,31,58,.15);
            }
            .button-secondary {
                border: 1px solid var(--border);
                background: white;
                color: var(--text);
            }
            .panel {
                border: 1px solid var(--border);
                border-radius: 28px;
                background: rgba(255,255,255,.82);
                backdrop-filter: blur(10px);
                box-shadow: 0 24px 60px rgba(15,23,42,.08);
                padding: 20px;
            }
            .stack { display: grid; gap: 14px; }
            .card {
                border: 1px solid var(--border);
                border-radius: 20px;
                background: white;
                padding: 16px;
            }
            .card strong {
                display: block;
                margin-bottom: 8px;
                font-size: 14px;
            }
            .grid {
                display: grid;
                gap: 16px;
                margin-top: 40px;
                grid-template-columns: repeat(3, minmax(0,1fr));
            }
            .grid h3 { margin: 0 0 10px; font-size: 18px; }
            .grid p { margin: 0; color: var(--muted); line-height: 1.7; }
            .note {
                margin-top: 28px;
                padding: 16px 18px;
                border-radius: 18px;
                background: rgba(216,162,27,.12);
                color: #854d0e;
                border: 1px solid rgba(216,162,27,.18);
                line-height: 1.7;
            }
            @media (max-width: 900px) {
                .hero, .grid { grid-template-columns: 1fr; }
                .wrap { padding-top: 24px; }
            }
        </style>
    </head>
    <body>
        <main class="wrap">
            <section class="hero">
                <div>
                    <p class="eyebrow">Nozan Service Center</p>
                    <h1>Backend control, admin access, and API foundation in one Laravel workspace.</h1>
                    <p class="lead">
                        ئەم repo ـە backend ـی سیستەمی نۆزانە. لێرەوە دەتوانیت Filament admin panel، API authentication، و بنەمای operations module ببینیت. بۆ گۆڕینی خودی live page ـی <strong>/jobs</strong> پێویستمان بە frontend repo ـیش هەیە.
                    </p>
                    <div class="actions">
                        <a href="{{ url('/admin/login') }}" class="button button-primary">Open admin panel</a>
                        <a href="{{ url('/ops-preview') }}" class="button button-secondary">Open operations preview</a>
                        <a href="{{ url('/api/auth/me') }}" class="button button-secondary">Test auth endpoint</a>
                    </div>
                    <div class="note">
                        تێبینی: ئەگەر لە live website گۆڕانکاری نابینیت، هۆکارەکە ئەوەیە ئەم backend ـە deploy نەکراوە یان ئەو شاشەیە لە frontend project ـێکی ترە.
                    </div>
                </div>
                <div class="panel stack">
                    <div class="card">
                        <strong>Admin panel</strong>
                        Filament dashboard لە <code>/admin</code> ئامادەیە بۆ back-office modules.
                    </div>
                    <div class="card">
                        <strong>Authentication</strong>
                        Sanctum endpoints: <code>/api/auth/login</code>, <code>/api/auth/me</code>, <code>/api/auth/logout</code>.
                    </div>
                    <div class="card">
                        <strong>Next build stages</strong>
                        Jobs, customers, payments, inventory, reports, و WhatsApp automation.
                    </div>
                </div>
            </section>

            <section class="grid">
                <article class="card">
                    <h3>Operations-ready foundation</h3>
                    <p>Laravel 12 + Filament 5 base stack بۆ سیستەمێکی پڕۆفیشناڵی service center.</p>
                </article>
                <article class="card">
                    <h3>Clear deployment path</h3>
                    <p>دەتوانرێت بە Git pull + migrate + cache refresh بۆ production deploy بکرێت.</p>
                </article>
                <article class="card">
                    <h3>Scalable SaaS direction</h3>
                    <p>company/branch-based isolation, finance modules, و API-first architecture بۆ mobile app.</p>
                </article>
            </section>
        </main>
    </body>
</html>
