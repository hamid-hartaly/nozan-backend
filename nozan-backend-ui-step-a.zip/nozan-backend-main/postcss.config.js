export default {
    plugins: {},
};
