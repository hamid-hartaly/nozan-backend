<?php

$defaultFrontendOrigins = [
    'https://nozan-service.com',
    'https://www.nozan-service.com',
];

return [
    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => array_values(array_filter([
        env('FRONTEND_URL', 'http://localhost:3000'),
        env('FRONTEND_URL_WWW'),
        'http://127.0.0.1:3000',
        ...$defaultFrontendOrigins,
    ])),

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,
];
