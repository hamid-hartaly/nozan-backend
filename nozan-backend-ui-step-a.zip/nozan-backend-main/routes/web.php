<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome');
Route::view('/ops-preview', 'ops-preview');
